Project Title: Smart Student Planner

Description:
Smart Planner is a C-based program designed to help students manage their daily academic schedule. The program allows users to generate a class timetable, view a personal daily planner, set reminders, and read motivation and health tips.

Features:
1. Generate class timetable based on section
2. Personal daily planner
3. Reminder setup
4. Motivation tips
5. Health tips

Technologies Used:
- C Programming
- File Handling
- HTML for timetable display

Output:
The program generates a timetable.html file which displays the timetable in a web browser.